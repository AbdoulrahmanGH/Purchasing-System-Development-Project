from http.client import HTTPResponse
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.db.models import QuerySet
from datetime import datetime
from app.models import Item
from app.models import Purchase_Order as po
from app.models import Quotation 
# Create your views here.

@login_required

def viewpurorder(request):
    queryset = po.objects.all()
    if request.method == 'POST':
        po_number = request.POST.get('po_number')
        date = request.POST.get('date')
        if po_number :
            queryset = queryset.filter(po_id=po_number)
        if date:
            queryset = queryset.filter(date_created=date)
        if po_number and date:
            queryset = queryset.filter(po_id=po_number,date_created=date)
        return render(request, 'viewpurorder/viewpurorder.html', {'queryset': queryset})
    return render(request, 'viewpurorder/viewpurorder.html', {'queryset': queryset})
