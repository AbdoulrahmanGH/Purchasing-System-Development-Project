from django.apps import AppConfig


class CreatepurorderConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'createpurorder'
