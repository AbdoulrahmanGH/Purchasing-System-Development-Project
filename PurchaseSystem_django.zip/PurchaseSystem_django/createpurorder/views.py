from django.shortcuts import render
from django import forms
from django.contrib.auth.decorators import login_required
from datetime import datetime
from app.models import *


# Create your views here.

@login_required
def createpurorderform(request):
    context = {
    'title':'Create Purchase Order Form',
    'year': datetime.now().year,
    }
    context['user'] = request.user

    return render(request,'createpurorder/createpurorderform.html',context)

def createpurorderconfirmation(request):
    newpurord_id = request.POST['purord_id']
    newpurord_date = request.POST['purord_date']
    newpurord_place = request.POST['purord_place']
    newpurord_method = request.POST['purord_method']
    newpurord_price = request.POST['purord_price']

    newpurord = Purchase_Order(po_id = newpurord_id, delivery_date = newpurord_date, fob_point = newpurord_place,
        shipping_method = newpurord_method, shipping_price = newpurord_price)
    newpurord.save()

    context = {
        'purord_id': newpurord_id,
        'purord_date': newpurord_date,
        'purord_place': newpurord_place,
        'purord_method': newpurord_method,
        'purord_price': newpurord_price
    }
    return render(request,'createpurorder/createpurorderconfirmation.html', context)

def createpurorderconfirmation(request):


    newpurord_id = request.POST['purord_id']
    newpurord_date = request.POST['purord_date']
    newpurord_price = request.POST['purord_price']
    newpurord_place = request.POST['purord_place']
    newpurord_method = request.POST['purord_method']

    newpurord = Purchase_Order(delivery_date = newpurord_date, po_id = newpurord_id, shipping_price = newpurord_price
    , fob_point = newpurord_place, shipping_method = newpurord_method)
    newpurord.save()

    context = {
        'purord_date': newpurord_date,
        'purord_id': newpurord_id,
        'purord_price': newpurord_price,
        'purord_place': newpurord_place,
        'purord_method': newpurord_method,
    }
    return render(request,'createpurorder/createpurorderconfirmation.html',context)

def additemform2(request):
    context = {
        'title': 'Add Item Form',
        'year': datetime.now().year,
    }
    context['user'] = request.user

    return render(request,'createpurorder/quotationlist.html',context)

def additemconfirmation2(request):
    
    newpurord_date = request.POST['purord_date']
    newpurord_place = request.POST['purord_place']
    newpurord_method = request.POST['purord_method']
    newpurord_price = request.POST['purord_price']

    newpurord = Purchase_Order(delivery_date = newpurord_date, fob_point = newpurord_place, 
        shipping_method = newpurord_method, shipping_price = newpurord_price)
    newpurord.save()

    context = {
        'purord_date': newpurord_date,
        'purord_place': newpurord_place,
        'purord_method': newpurord_method,
        'purord_price': newpurord_price,
    }
    return render(request,'createpurorder/creatpurorderconfirmation.html',context)

def selectquotation(request):

    quotation_list = Quotation.objects.filter(approval='Approved')
    context = {
        'quotation_list':quotation_list,
    }

    return render(request,'createpurorder/quotationlist.html',context)

def viewQR(request):
    queryset = Quotation.objects.all()
    return render(request, 'createpurorder/quotationlist.html', {'queryset': queryset})
