from django import forms
from django.shortcuts import render
from app.models import *

class ExampleForm(forms.Form):
    CHOICES = (
        ('option1', 'Option 1'),
        ('option2', 'Option 2'),
        ('option3', 'Option 3'),
    )
    select = forms.ChoiceField(choices=CHOICES)

def example_view(request):
    form = ExampleForm()
    return render(request, 'createpurorder/quotationlist.html', {'form': form})

def selectquotation(request):

    quotation_list = Quotation.objects.filter(approval='TBD')
    context = {
        'quotation_list':quotation_list,
    }
    select = forms.ChoiceField(choices=context)
    return render(request,'createpurorder/quotationlist.html',context)