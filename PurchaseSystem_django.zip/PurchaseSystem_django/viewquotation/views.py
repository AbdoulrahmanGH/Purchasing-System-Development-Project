from django.shortcuts import render
from datetime import datetime
from app import models

# Create your views here.

def quotation_view(request):

    if request.method == 'GET':
        q_id = request.GET.get('q_id', None)
        date = request.GET.get('date', None)
        quotations = models.Quotation.objects.all()
        if q_id:
            quotations = quotations.filter(quotation_id = q_id)
        if date:
            quotations = quotations.filter(date_created = date)
        if q_id and date:
            quotations = quotations.filter(quotation_id = q_id, date_created = date)
   
    context = {
        'title': 'View Quotations',
        'year': datetime.now().year,
        'quotations': quotations
    }
    context['user'] = request.user

    return render(request, 'viewquotation/quotationlist.html', context)

def quotation_detail(request):
    context = {
        'title': 'View Quotations',
        'year': datetime.now().year
    }
    
    id = request.GET.get('id', None)
    quotation = models.Quotation.objects.get(quotation_id=id)
    items = models.Quotation_Item.objects.filter(quotation = id)
    context['quotation'] = quotation
    context['items'] = items

    return render(request, 'viewquotation/quotationdetail.html', context)
