from http.client import HTTPResponse
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.db.models import QuerySet
from datetime import datetime
from app.models import Item
from app.models import Purchase_Order as po
from app.models import Quotation 
# Create your views here.

@login_required

def viewPO(request):
    queryset = po.objects.all()
    if request.method == 'POST':
        po_number = request.POST.get('po_number', None)
        date = request.POST.get('date', None)
        if po_number :
            queryset = queryset.filter(po_id=po_number)
        if date:
            queryset = queryset.filter(date_created=date)
        if po_number and date:
            queryset = queryset.filter(po_id=po_number,date_created=date)
        return render(request, 'viewpurchaseorder/viewpurchaseorder.html', {'queryset': queryset})
    return render(request, 'viewpurchaseorder/viewpurchaseorder.html', {'queryset': queryset})

def viewQR(request):
    queryset = Quotation.objects.all()
    if request.method == 'POST':
        qr_number = request.POST.get('qr_number', None)
        date = request.POST.get('date', None)
        if qr_number :
            queryset = queryset.filter(quotation_id=qr_number)
        if date:
            queryset = queryset.filter(date_created=date)
        if qr_number and date:
            queryset = queryset.filter(quotation_id=qr_number,date_created=date)
        return render(request, 'viewpurchaseorder/viewquotationlist.html', {'queryset': queryset})
    return render(request, 'viewpurchaseorder/viewquotationlist.html', {'queryset': queryset})
