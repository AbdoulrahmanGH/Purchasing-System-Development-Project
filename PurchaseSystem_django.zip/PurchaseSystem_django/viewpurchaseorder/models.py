"""
Definition of models.
"""

from django.db import models
import decimal
from django.contrib.auth.models import User
