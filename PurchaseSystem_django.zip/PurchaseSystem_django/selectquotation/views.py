from django.shortcuts import render
from app import models
from datetime import datetime

# Create your views here.
def select_quotation(request):

    quotations = models.Quotation.objects.filter(approval='TBD')

    context = {
        'title': 'Select Quotation',
        'year': datetime.now().year,
        'quotations': quotations
    }
    context['user'] = request.user

    return render(request, 'selectquotation/selectquotation.html', context)

def approve_quotation(request, id):

    context = {}
    q_id = request.POST.get('id', None)

    quotation = models.Quotation.objects.get(quotation_id=q_id)
    items = models.Quotation_Item.objects.filter(quotation = q_id)

    context['quotation'] = quotation
    context['items'] = items
    context['id'] = id

    return render(request, 'selectquotation/approvequotation.html', context)

def change_approval(request, id):

    approve = request.GET.get('approval', None)
    quote = models.Quotation.objects.get(quotation_id=id)
    quote.approval = approve
    quote.save()

    context = {
        'title': 'Select Quotation',
        'year': datetime.now().year,
        'approve': approve,
        'id': id
    }

    return render(request, 'selectquotation/confirmation.html', context)