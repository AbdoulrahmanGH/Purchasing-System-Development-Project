from django.apps import AppConfig


class SelectquotationConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'selectquotation'
