"""myproject URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, re_path
from app import views as main_views
import django.contrib.auth.views
from django.contrib.auth.views import LoginView, LogoutView
from datetime import datetime

from additem import views as additem_views
from viewquotation import views as viewquotation_views
from selectquotation import views as selectquotation_views
from viewpurchaseorder import views as viewpurchaseorder_views
from viewpurorder import views as viewpurorder_views
from createpurorder import views as createpurorder_views

admin.autodiscover()

urlpatterns = [
    path('admin/', admin.site.urls),
    re_path(r'^$', main_views.home, name='home'),
    re_path(r'^contact$', main_views.contact, name='contact'),
    re_path(r'^about$', main_views.about, name='about'),
    re_path(r'^login/$',
        LoginView.as_view(template_name = 'app/login.html'),
        name='login'),
    re_path(r'^logout$',
        LogoutView.as_view(template_name = 'app/index.html'),
        name='logout'),
    re_path(r'^menu$', main_views.menu, name='menu'),

    re_path(r'^additemform$', additem_views.additemform, name='additem_form'),
    re_path(r'^additemconfirmation$', additem_views.additemconfirmation, name='additem_confirmation'),

    re_path(r'^viewpurchaseorder$', viewpurchaseorder_views.viewPO, name='viewpurchaseManager'),
    re_path(r'^viewquotationlist$', viewpurchaseorder_views.viewQR, name='viewquotationManager'),

    re_path(r'^quotationlist$', createpurorder_views.selectquotation, name='quotation_list'),

    re_path(r'^additemform2$', createpurorder_views.additemform2, name='additem_form2'),
    re_path(r'^additemconfirmation2$', createpurorder_views.additemconfirmation2, name='additem_confirmation2'),
    
    re_path(r'createpurorderform$', createpurorder_views.createpurorderform, name='createpurorder_form'),
    re_path(r'createpurorderconfirmation$', createpurorder_views.createpurorderconfirmation, name='createpurorder_confirmation'),

    re_path(r'^viewpurorder$', viewpurorder_views.viewpurorder, name='viewpuroder'),

    re_path(r'^viewquotations$', viewquotation_views.quotation_view, name='view_quotations'),
    re_path(r'^quotationdetail$', viewquotation_views.quotation_detail, name='quotation_detail'),

    re_path(r'^selectquotation$', selectquotation_views.select_quotation, name='select_quotation'),
    path('approvequotation/<int:id>', selectquotation_views.approve_quotation, name='approve_quotation'),
    path('approvequotation/confirmation/<int:id>', selectquotation_views.change_approval, name='confirmation')

]
