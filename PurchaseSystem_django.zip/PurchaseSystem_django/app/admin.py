from django.contrib import admin

from app.models import Item, Employee, Quotation, Quotation_Item, Purchase_Order, PO_Item

admin.site.register(Item)
admin.site.register(Employee)
admin.site.register(Quotation)
admin.site.register(Quotation_Item)
admin.site.register(Purchase_Order)
admin.site.register(PO_Item)

