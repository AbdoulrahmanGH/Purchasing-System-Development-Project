"""
Definition of models.
"""

from django.db import models
import decimal
from django.contrib.auth.models import User

#sharing entity

class Item(models.Model):
    item_id = models.AutoField(primary_key=True)
    item_name = models.TextField()
    item_description = models.TextField(null=True,default=None, blank=True)

    def __str__(self):
        return str(self.item_name)

class Employee(models.Model):
    employee_id = models.AutoField(primary_key=True)
    employee_name = models.TextField(max_length=255)
    employee_email = models.TextField(max_length=255)

    def __str__(self):
        return str(self.employee_name)

class Quotation(models.Model):
    quotation_id = models.AutoField(primary_key=True)
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE)
    item = models.ManyToManyField(Item, through='Quotation_Item')
    seller_name = models.TextField(max_length=255)
    seller_email = models.TextField(max_length=255)
    date_created = models.DateField()
    valid_date = models.DateField()
    discount = models.DecimalField(max_digits=5, decimal_places=2)
    total_price = models.DecimalField(max_digits=20, decimal_places=2, editable=False, null=True)

    def save(self, *args, **kwargs):
        if not getattr(self, "quotation_id"):
            super(Quotation, self).save(*args, **kwargs)
        else:
            total = decimal.Decimal(0.0) # should be DecimalField not integer or float or prices
            for items in Quotation_Item.objects.filter(quotation = self.quotation_id):
                total += items.full_price
            aftdisc = total - (total * self.discount)
            self.total_price = aftdisc # again this should be changed to DecimalField
        super(Quotation, self).save(*args, **kwargs)

    APPROVED = "Approved"
    NOT_APPROVED = "Not Approved"
    TBD = "TBD"

    APPROVAL_CHOICES = {
        (APPROVED, "Approved"),
        (NOT_APPROVED, "Not Approved"),
        (TBD, "TBD")
    }
    approval = models.CharField(max_length=13, choices=APPROVAL_CHOICES, default=TBD)

    def __str__(self):
        return str(self.quotation_id)


class Quotation_Item(models.Model):
    item = models.ForeignKey(Item, on_delete=models.CASCADE)
    quotation = models.ForeignKey(Quotation, on_delete=models.CASCADE)
    item_price = models.DecimalField(max_digits=10, decimal_places=2)
    item_quantity = models.IntegerField()
    full_price = models.DecimalField(max_digits=20, decimal_places=2, editable=False, default=0.0)

    def save(self, *args, **kwargs):
        total = 0.0 # should be DecimalField not integer or float for prices
        total = self.item_quantity * self.item_price
        self.full_price = total # again this should be changed to DecimalField
        super(Quotation_Item, self).save(*args, **kwargs)
    
    def __str__(self):
        return str(self.quotation)

    class Meta:
        unique_together = [['item', 'quotation']]

class Purchase_Order(models.Model):
    po_id = models.AutoField(primary_key=True)
    quotation = models.ForeignKey(Quotation, on_delete=models.CASCADE)
    item = models.ManyToManyField(Item, through='PO_Item')
    date_created = models.DateField()
    delivery_date = models.DateField()
    shipping_method = models.TextField(max_length=255)
    fob_point = models.TextField(max_length=255)
    shipping_price = models.DecimalField(max_digits=20, decimal_places=2)
    total_price = models.DecimalField(max_digits=20, decimal_places=2, editable=False, null=True)

    def save(self, *args, **kwargs):
        if not getattr(self, "po_id"):
            super(Purchase_Order, self).save(*args, **kwargs)
        else:
            total = decimal.Decimal(0.0) # should be DecimalField not integer or float or prices

            for items in PO_Item.objects.filter(po = self.po_id):
                total += items.full_price

            self.total_price = total + self.shipping_price # again this should be changed to DecimalField
        super(Purchase_Order, self).save(*args, **kwargs)

    def __str__(self):
        return str(self.po_id)

class PO_Item(models.Model):
    item = models.ForeignKey(Item, on_delete=models.CASCADE)
    po = models.ForeignKey(Purchase_Order, on_delete=models.CASCADE)
    item_price = models.DecimalField(max_digits=5, decimal_places=2)
    item_quantity = models.IntegerField()
    full_price = models.DecimalField(max_digits=5, decimal_places=2, editable=False, default=0.0)
     
    def save(self, *args, **kwargs):
        total = 0.0 # should be DecimalField not integer or float for prices
        total = self.item_quantity * self.item_price
        self.full_price = total # again this should be changed to DecimalField
        super(PO_Item, self).save(*args, **kwargs)
    
    def __str__(self):
        return str(self.po_id)

    class Meta:
        unique_together = [['item', 'po']]